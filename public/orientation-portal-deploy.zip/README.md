# Pack de déploiement — Orientation Portal 2nd

Ce pack contient le **strict minimum** pour déployer facilement l'application **Orientation Portal 2nd** sur n'importe quelle machine ou sur un autre serveur Pterodactyl.

---

## Contenu du pack

- `index.js` : Script de bootstrap intelligent (clone la dernière version du code source depuis GitHub, installe les dépendances, génère le client Prisma, compile le projet Next.js et démarre le serveur).
- `package.json` : Fichier de définition des dépendances.
- `.env` : Variables d'environnement préconfigurées (base de données, clés API Gemini/OpenRouter, NextAuth, SMTP, Push VAPID, Telegram).
- `deploy.sh` : Script bash clé en main pour déployer en 1 commande sur un serveur Linux avec PM2.
- `Dockerfile` & `docker-compose.yml` : Pour déployer instantanément via Docker.

---

## Méthode 1 : Sur un autre serveur Pterodactyl (Recommandé)

1. Créez un nouveau serveur Pterodactyl avec l'Egg **Node.js Generic** (image `ghcr.io/ptero-eggs/yolks:nodejs_25` ou `nodejs_22`).
2. Dans le gestionnaire de fichiers Pterodactyl, uploadez et extrayez ce zip (ou déposez simplement `index.js`, `package.json` et `.env`).
3. Vérifiez dans l'onglet **Startup** du serveur que le fichier principal (`MAIN_FILE`) est bien défini sur `index.js`.
4. Cliquez sur **Start** : le serveur va automatiquement télécharger le code source depuis GitHub, builder et démarrer l'application.

---

## Méthode 2 : Sur un VPS Linux brut (sans Docker)

1. Décompressez l'archive dans un dossier :
   ```bash
   unzip orientation-portal-deploy.zip -d /var/www/orientation-portal
   cd /var/www/orientation-portal
   ```
2. Rendez le script exécutable et lancez-le :
   ```bash
   chmod +x deploy.sh
   ./deploy.sh
   ```
3. L'application est lancée et supervisée par PM2 :
   - Voir les logs : `pm2 logs orientation-portal-2nd`
   - Voir le statut : `pm2 status`

---

## Méthode 3 : Avec Docker Compose

1. Décompressez l'archive :
   ```bash
   unzip orientation-portal-deploy.zip -d orientation-portal
   cd orientation-portal
   ```
2. Lancez le conteneur en arrière-plan :
   ```bash
   docker compose up -d
   ```
3. Voir les logs :
   ```bash
   docker compose logs -f
   ```

---

## Note sur la base de données
Le fichier `.env` inclus pointe vers la base de données actuelle (`172.18.0.1:3306`). Si la nouvelle machine se trouve sur un autre réseau, modifiez la variable `DATABASE_URL` dans le fichier `.env` pour cibler votre serveur MySQL.
