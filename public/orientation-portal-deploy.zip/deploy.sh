#!/usr/bin/env bash
set -e

echo "=========================================================="
echo "    Déploiement Automatique - Orientation Portal 2nd     "
echo "=========================================================="

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# 1. Vérification / Installation de Git
if ! command -v git >/dev/null 2>&1; then
    echo "▶ Installation de git..."
    if command -v apt-get >/dev/null 2>&1; then
        sudo apt-get update && sudo apt-get install -y git
    fi
fi

# 2. Vérification / Installation de Node.js
if ! command -v node >/dev/null 2>&1; then
    echo "▶ Installation de Node.js 22 LTS..."
    if command -v apt-get >/dev/null 2>&1; then
        curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
        sudo apt-get install -y nodejs
    else
        echo "Veuillez installer Node.js (version >= 20) manuellement sur votre système."
        exit 1
    fi
fi

echo "✓ Node.js version : $(node -v)"
echo "✓ NPM version : $(npm -v)"

# 3. Vérification / Installation de PM2
if ! command -v pm2 >/dev/null 2>&1; then
    echo "▶ Installation de PM2..."
    sudo npm install -g pm2
fi

# 4. Lancement avec PM2
echo "▶ Démarrage de l'application..."
pm2 start index.js --name "orientation-portal-2nd"
pm2 save

echo ""
echo "=========================================================="
echo "✓ Application déployée avec succès !"
echo "• Statut : pm2 status"
echo "• Logs en direct : pm2 logs orientation-portal-2nd"
echo "• Port d'écoute : 3002 (ou défini par APP_PORT)"
echo "=========================================================="
