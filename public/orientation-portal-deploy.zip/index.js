const { execSync, spawn } = require('child_process');
const fs = require('fs');
const os = require('os');

console.log('==================================================');
console.log('    DÉMARRAGE DU PORTAIL ORIENTATION               ');
console.log('==================================================\n');

try {
  console.log('▶ [1/4] Mise à jour depuis GitHub (Auto-Update)...');
  const token = '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';
  const repo = `https://${token}@github.com/nexos20lv/orientation-portal.git`;

  try {
    execSync('git config --global --add safe.directory "*"');
  } catch (e) {}

  try {
    execSync('git rev-parse --is-inside-work-tree', { stdio: 'ignore' });
  } catch (e) {
    console.log('Initialisation du dépôt Git...');
    execSync('git init', { stdio: 'inherit' });
  }

  try {
    execSync(`git remote set-url origin ${repo}`, { stdio: 'ignore' });
  } catch (e) {
    execSync(`git remote add origin ${repo}`, { stdio: 'ignore' });
  }

  console.log('Téléchargement de la dernière version (main)...');
  execSync('git fetch --all', { stdio: 'inherit' });
  execSync('git reset --hard origin/main', { stdio: 'inherit' });

  console.log('\nVérification des dépendances NPM...');
  execSync('npm install --legacy-peer-deps', { stdio: 'inherit' });

  console.log('\n▶ [2/4] Génération du client Prisma...');
  execSync('npx prisma generate', { stdio: 'inherit' });

  console.log('\n▶ [3/4] Compilation de Next.js (Build)...');
  execSync('npm run build', { stdio: 'inherit' });

  console.log('\n▶ [4/4] Démarrage du serveur web...');
  const port = process.env.APP_PORT || process.env.PORT || 3002;

  const nextProcess = spawn('npx', ['next', 'start', '-H', '0.0.0.0', '-p', port], { 
    stdio: 'inherit',
    shell: true 
  });

  nextProcess.on('close', (code) => {
    console.log(`Le serveur Next.js s'est arrêté avec le code ${code}`);
    process.exit(code);
  });

} catch (error) {
  console.error('\n❌ UNE ERREUR CRITIQUE EST SURVENUE LORS DU DÉMARRAGE :');
  console.error(error);
  process.exit(1);
}
